I have created TWO JAR files.
1)  The PaceCalculator.jar is the executable JAR.  To use the executable:
   a)  On Windows, just double-click on the PaceCalculator.jar file.
   b)  On the Linux/Unix side, open a shell and navigate to where the
       PaceCalculator.jar file is located.
       1)  In the shell, type java -jar PaceCalculator.jar
   c)  This will start the executable.

2)  The pacecalulatorsourcecode.jar is the source code used to make
    this version of the PaceCalculator.
    a)  It contains both all the source code and the class files for the
        application.


If there are any questions or comments, please email me at:
fractioncalc@gmail.com
