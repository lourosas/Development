/********************************************************************
The RPN Fraction Calculator Application.
Copyright (C) 2007 Lou Rosas

This file is part of RPNFractionCalculator
RPNFractionCalculator is free software; you can redistribute it
and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

RPNFractionCalculator is distributed in the hope that it will be
useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
package rosas.lou.calculator;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import myclasses.*;
import rosas.lou.*;
import rosas.lou.calculator.*;

/********************************************************************
The RPNFractionCalculatorView class by Lou Rosas.  This class
contains all the attributes and operations related to the
view of the RPNFractionCalcualator-->essentially, it is the GUI
the user sees on the screen and with which the user interacts.
********************************************************************/
public class RPNFractionCalculatorView extends GenericJFrame
implements Observer{

   //The appropriate attributes and types
   private static final short WIDTH  = 360;
   private static final short HEIGHT = 370;

   private Object controller;  //Set up the controller
   private JTextField viewTextField;
   private ButtonGroup buttonGroup, menuItemGroup, radioButtonGroup;
   private GenericJInteractionFrame stackFrame;
   private JTextArea stackTextArea;
   private Fraction currentFraction;
   private boolean fractionDisplayState;

   /***********************Public Methods***************************/
   /*****************************************************************
   Constructor of no arguments.
   *****************************************************************/
   public RPNFractionCalculatorView(){
      //Call the constructor and pass an empty string
      this("");
   }

   /*****************************************************************
   Constructor taking a String attribute--for the title.
   *****************************************************************/
   public RPNFractionCalculatorView(String title){
      super(title);  //Call the super class
      //Set up the gui
      this.setUpGUI();
      //Instantiate the controller, passing in a reference to this
      //object  (will need to cast as appropriate)
      controller = new RPNFractionCalculatorController(this);
      //Add listeners to the gui (so many of them)
      this.addListeners();
      //Set up the Display to reflect the x-register
      this.setText("0/1");
      this.selectRequestTextField();
      this.setFractionDisplayState(true);
      //By default, enable the "spc" button
      this.enableButton("Spc", true);
      this.setResizable(false);
      this.setVisible(true);
   }
   
   /*****************************************************************
   Display the About dialog box
   *****************************************************************/
   public void displayAbout(){
      String about = "RPNFractionCaluculator vesion 0.1\n";
      about += "Copyright (C) 2007 Lou Rosas\n";
      about += "This program comes with ABSOLUTELY NO WARRANTY\n";
      about += "This is free software, and you are welcome to\n";
      about += "to redistribute it under certain conditions.\n";
      about += "For details, please see the GNU General Public\n";
      about += "License at:  <http://www.gnu.org/licenses/>\n";
      about += "For comments or questions please contact me at:\n";
      about += "fractioncalc@gmail.com\n\n";
      JOptionPane.showMessageDialog(this, about, 
                            "RPNFractionCalculator",
                            JOptionPane.INFORMATION_MESSAGE);
   }
   
   /*****************************************************************
   Display the Keyboard Help Dialog Box
   *****************************************************************/
   public void displayKeyboardHelp(){
      String keyHelp = "Certain Keys on the Keyboard can be\n";
      keyHelp += "pressed instead of the GUI Buttons or Menu Items.";
      keyHelp += "\nThey are:\n1) '0' - '9' for numbers.";
      keyHelp += "\n2) '/' for the numerator/denominator separator.";
      keyHelp += "\n3) '+', '-', '*' for the appropriate math";
      keyHelp += "operation.";
      keyHelp += "\n4) 'd' or 'D' for division.";
      keyHelp += "\n5) 'c' or 'C' for clear.";
      keyHelp += "\n6) 'e' or 'E' for X, Y register exchange\n";
      keyHelp += "(same as the 'x<-->y' button).";
      keyHelp += "\n7) 'i' or 'I' for the Reciprocal (Inverse)\n";
      keyHelp += "button (same as the '1/x' button)";
      keyHelp += "\n8) 'r' or 'R' for the Rolldown button\n";
      keyHelp += "this button rolls the x-register to the bottom\n";
      keyHelp += "of the stack--putting the y-register value in\n";
      keyHelp += "x-register.";
      keyHelp += "\n9) F3 for the change sign '(-)' button.";
      keyHelp += "\n10) F6 to view the contents of the stack.";
      keyHelp += "\n11) Backspace key for the backspace\n";
      keyHelp += "(same as the 'bkspc' button).";
      keyHelp += "\n12) Spacebar for the 'Spc' button";
      keyHelp += " self explanatory.";
      JOptionPane.showMessageDialog(this, keyHelp,
                                    "Keyboard Help",
                                    JOptionPane.INFORMATION_MESSAGE);
   }
      
   /*****************************************************************
   Display the Help dialog box
   *****************************************************************/
   public void displayHelp(){
      String help = "This Help Topic Currently contains\n";
      help += "information related to the Reverse Polish Notation\n";
      help += "Fraction Calculator:  Release 0.1\n\n";
      help += "This caluclator works in the same way as any other\n";
      help += "Reverse Polish Notation (RPN) calculator--except\n";
      help += "that it handles fraction arithmetic.  This ";
      help += "calculator does\nnot contain a decimal point and ";
      help += "there are no decimal\n";
      help += "conversions in this calculator.  All ";
      help += "numbers are treated\nas fractions:  even whole";
      help += "numbers.  Enter fractions as\nyou normally would, ";
      help += "with the '/' separating the\nNumerator from the ";
      help += "Denominator.\n\nThe user is expected to know how ";
      help += "to use an\nRPN Calcuator.\n\n All fractions are ";
      help += "reduced to their lowest forms\nand are displayed in ";
      help += "that format.  This calculator\nwill inform the user ";
      help += "if a current fraction is undefined\nor not entered ";
      help += "properly:  asking the user to re-enter an\n";
      help += "appropriate Fraction.\n\nIn this current release, ";
      help += "this calculator converts proper\nfractions ";
      help += "to improper fractions and and vice-versa.\nProper ";
      help += "fractions are entered by placing a space between\n";
      help += "the proper and fraction values (the first number\n";
      help += "and the numerator).  The space can be entered by\n";
      help += "pressing the Spacebar or the \"Spc\" button\n";
      help += "on the GUI.  This application ignores excess \n";
      help += "spaces placed between the proper and fractional\n";
      help += "numbers.\n\nThis application ";
      help += "allows the user the option of\ndisplaying the ";
      help += "fractions as proper or improper.\nImproper fractions";
      help += " are displayed in numerator/denominator\nformat ";
      help += "regardless of the size of the numerator as ";
      help += "compared\nto the denominator.  In proper mode, ";
      help += "all improper fractions\nwill be displayed as ";
      help += "proper and vice-versa for improper\nmode.  ";
      help += "To change from one mode to the other, select the\n";
      help += "appropriate radio button between the textfield\n";
      help += "and the button-pad.  In Improper mode, the \"Spc\"\n";
      help += "button is disabled: as with the Spacebar on the ";
      help += "keyboard.\n\nFor help on which keys on the ";
      help += "keyboard can be used\nfor this application, consult ";
      help += "the \"Keyboard Help\" Menu\nItem under the \"Help\" ";
      help += "Menu (Help->Keyboard Help).";
      JOptionPane.showMessageDialog(this, help,
                             "Help",
                             JOptionPane.INFORMATION_MESSAGE);
   }

   /*****************************************************************
   Implementation of the update method as part of the implementation
   of the Observer interface.
   *****************************************************************/
   public void update(Observable o, Object arg){
      if(arg instanceof Fraction){
         this.printFraction((Fraction)arg);
         //Since this was an update, go ahead and enable the
         //Slash ("/") button--indicating the slash button
         //has not been pressed yet.
         this.setSlashPressed(false);
         //Put this here for now, might need to change (or remove)
         this.selectRequestTextField();
         //If the stackFrame instance is showing, go ahead and
         //update it.  Do it the easy way by requesting a "stack"
         //button press.
         if(this.stackFrame.isShowing()){
            this.clickButton("stack");
         }
      }
      else if(arg instanceof Stack){
         Stack tempStack = (Stack)arg;
         this.displayStackFrame(tempStack);
      }
      else if(arg instanceof FractionException){
         FractionException fe = (FractionException)arg;
         this.showErrorDialog(fe.getReason());
      }
      else if(arg instanceof String){
         String string = (String)arg;
         if(string.equals("fraction display state-true")){
            this.setFractionDisplayState(true);
         }
         else if(string.equals("fraction display state-false")){
            this.setFractionDisplayState(false);
         }
      }
   }
   
   /*****************************************************************
   "Click" the requested button
   *****************************************************************/
   public void clickButton(String buttonText){
      Enumeration e = this.buttonGroup.getElements();
      boolean isFound = false;
      while(e.hasMoreElements() && !isFound){
         JButton b = (JButton)e.nextElement();
         if(b.getText().equals(buttonText)){
            isFound = true;
            b.doClick();
         }
      }
   }

   /*****************************************************************
   Grab the text out of the Text Field
   *****************************************************************/
   public String getText(){
      return this.viewTextField.getText();
   }
   
   /*****************************************************************
   *****************************************************************/
   public String getSelectedText(){
      return this.viewTextField.getSelectedText();
   }

   /*****************************************************************
   Grab the Fraction in the TextField and return it to the
   messaging object.
   THROWS: NullPointerException
   *****************************************************************/
   public Fraction grabFraction() throws NullPointerException{
      Fraction returnFraction;
      String fractionString = this.getText();

      try{
         returnFraction = new Fraction(fractionString);
      }
      catch(FractionException fe){
         fe.printStackTrace();
         //Show the dialog box for the reason for the error
         this.showErrorDialog(fe.getReason());
         throw(new NullPointerException());
      }
      return returnFraction;
   }
   
   /*****************************************************************
   Request focus on the JTextField component only--don't select
   anything in the JTextField
   *****************************************************************/
   public void requestTextField(){
      this.viewTextField.requestFocus();
   }

   /*****************************************************************
   Select the text field and request focus
   *****************************************************************/
   public void selectRequestTextField(){
      this.viewTextField.requestFocus();
      this.viewTextField.selectAll();
   }

   /*****************************************************************
   Set the text in the Text field.
   *****************************************************************/
   public void setText(String text){
      this.viewTextField.setText(text);
   }
   
   /*****************************************************************
   Indicate if the slash was pressed.  If the slash was pressed,
   message to disable the slash ('/') button. Else, message to enable
   the slash button.
   *****************************************************************/
   public void setSlashPressed(boolean pressed){
      if(pressed)
         this.enableButton("/", false);
      else
         this.enableButton("/", true);
   }

   /**********************Private Methods***************************/
   /*****************************************************************
   Add the appropriate Listeners to the the appropriate GUI
   components.
   *****************************************************************/
   private void addListeners(){
      //Add the ActionListener to the Text Field (for the "Enter"
      //button being pressed when the Text Field has focus
      this.viewTextField.addActionListener((ActionListener)controller);
      this.viewTextField.addKeyListener((KeyListener)controller);
      
      //Add Listeners to the JButtons
      Enumeration e = this.buttonGroup.getElements();
      while(e.hasMoreElements()){
         JButton button = (JButton)e.nextElement();
         button.addActionListener((ActionListener)controller);
         button.addKeyListener((KeyListener)controller);
      }
      
      //Add Listeners to the JMenuItems
      e = this.menuItemGroup.getElements();
      while(e.hasMoreElements()){
         JMenuItem item = (JMenuItem)e.nextElement();
         item.addActionListener((ActionListener)controller);
      }
      
      //Add Listeners to the JRadioButtons
      e = this.radioButtonGroup.getElements();
      while(e.hasMoreElements()){
         JRadioButton jrb = (JRadioButton)e.nextElement();
         jrb.addItemListener((ItemListener)controller);
      }
   }
   
   /*****************************************************************
   Display the Stack in its own frame (not on the System command
   line).  Display the Stack contents in its own window.
   *****************************************************************/
   private void displayStackFrame(Stack stack){
      int stackSize = stack.size();
      for(int i = 0; i < stackSize; i++){
         Fraction fraction = (Fraction)stack.pop();
         if(i == 0)
            stackTextArea.setText(fraction.toString());
         else{
            String currentText = stackTextArea.getText();
            currentText += "\n" + fraction.toString();
            stackTextArea.setText(currentText);
         }
      }
      if(!this.stackFrame.isShowing()){
         this.stackFrame.setVisible(true);
      }
   }

   /*****************************************************************
   Enable/Disable the requested button on the GUI.
   *****************************************************************/
   private void enableButton(String buttonString, boolean enable){
      Enumeration e = this.buttonGroup.getElements();
      while(e.hasMoreElements()){
         JButton b = (JButton)e.nextElement();
         String  s = b.getText();
         if(s.equals(buttonString)){
            b.setEnabled(enable);
         }
      }
   }
   
   /*****************************************************************
   Return the fractionDisplayState boolean--this is how to display
   the fractions--set the Fractions display state to this (as
   needed which is currently always)
   *****************************************************************/
   private boolean getFractionDisplayState(){
      return this.fractionDisplayState;
   }
   
   /*****************************************************************
   Print the fraction to the TextField in the gui.
   *****************************************************************/
   private void printFraction(Fraction fraction){
      fraction.setDisplayState(this.getFractionDisplayState());
      this.setText(fraction.toString());
      //Have the TextField request focus for further arithmetic
      //operations.
      this.requestTextField();
   }

   /*****************************************************************
   Set up the GUI for display.
   *****************************************************************/
   private void setUpGUI(){
      //Get the content pane container
      Container contentPane = this.getContentPane();
      //Get the screen dimensions
      Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
      //Set the size
      this.setSize(WIDTH, HEIGHT);
      //Set up the location
      this.setLocation(
         (int)(dim.getWidth()/2  - WIDTH/2),
         (int)(dim.getHeight()/2 - HEIGHT/2)
      );
      //Set up the appropriate panels
      contentPane.add(this.setNorthPanel(),  BorderLayout.NORTH);
      contentPane.add(this.setCenterPanel(), BorderLayout.CENTER);
      //Set up the menu bar
      this.setJMenuBar(this.setUpMenuBar());
      //Set up the Stack Frame
      this.setUpStackFrame();
   }

   /*****************************************************************
   Set up the North Panel of the gui and return the JPanel
   *****************************************************************/
   private JPanel setNorthPanel(){
      JPanel northPanel = new JPanel();

      //Set up the border
      northPanel.setBorder(
                      BorderFactory.createEmptyBorder(14,30,14,30)
      );

      northPanel.setLayout(new GridLayout(1,1));
      this.viewTextField = new JTextField();
      northPanel.add(viewTextField);
      //Set the TextField un-editable, so that only the appropriate
      //events can be set for the appropriate action
      this.viewTextField.setEditable(false);

      return northPanel;
   }

   /*****************************************************************
   Set up the Center Panel of the gui and return the JPanel
   *****************************************************************/
   private JPanel setCenterPanel(){
      JPanel centerPanel = new JPanel();
      centerPanel.setLayout(new BorderLayout());
      centerPanel.setBorder(BorderFactory.createEtchedBorder());

      centerPanel.add(this.setUpRBPanel(), BorderLayout.NORTH);
      centerPanel.add(this.setUpButtonPanel(), BorderLayout.CENTER);

      return centerPanel;
   }
   
   /*****************************************************************
   Set the fractionDisplayState boolean attribute.
   *****************************************************************/
   private void setFractionDisplayState(boolean displayState){
      this.fractionDisplayState = displayState;
      //Based on the fraction display state, enable or disable the
      //Space "Spc" button
      this.enableButton("Spc", displayState);      
   }

   /*****************************************************************
   Set up the Button Panel
   *****************************************************************/
   private JPanel setUpButtonPanel(){
      JPanel buttonPanel = new JPanel();
      buttonPanel.setBorder(
                         BorderFactory.createEmptyBorder(15,15,15,15)
      );
      buttonPanel.setLayout(new GridLayout(6,4,4,4));

      //Instantiate the button group
      buttonGroup = new ButtonGroup();

      //Set up the buttons and add to the GUI
      JButton clear      = new JButton("C");
      clear.setMnemonic(KeyEvent.VK_C);
      JButton backspace  = new JButton("bkspc");
      JButton exchange   = new JButton("x<->y");
      JButton enter      = new JButton("Enter");
      JButton changeSign = new JButton("(-)");
      JButton rollDown   = new JButton("rdn");
      JButton inverse    = new JButton("1/x");
      JButton add        = new JButton("+");
      JButton seven      = new JButton("7");
      JButton eight      = new JButton("8");
      JButton nine       = new JButton("9");
      JButton minus      = new JButton("-");
      JButton four       = new JButton("4");
      JButton five       = new JButton("5");
      JButton six        = new JButton("6");
      JButton multiply   = new JButton("*");
      JButton one        = new JButton("1");
      JButton two        = new JButton("2");
      JButton three      = new JButton("3");
      JButton divide     = new JButton("Div");
      divide.setMnemonic(KeyEvent.VK_V);
      JButton zero       = new JButton("0");
      JButton slash      = new JButton("/");
      JButton space      = new JButton("Spc");
      JButton stack      = new JButton("stack");
      
      //Add the buttons to the JPanel and the ButtonGroup objects
      buttonPanel.add(clear);      this.buttonGroup.add(clear);
      buttonPanel.add(backspace);  this.buttonGroup.add(backspace);
      buttonPanel.add(exchange);   this.buttonGroup.add(exchange);
      buttonPanel.add(enter);      this.buttonGroup.add(enter);
      buttonPanel.add(changeSign); this.buttonGroup.add(changeSign);
      buttonPanel.add(rollDown);   this.buttonGroup.add(rollDown);
      buttonPanel.add(inverse);    this.buttonGroup.add(inverse);
      buttonPanel.add(add);        this.buttonGroup.add(add);
      buttonPanel.add(seven);      this.buttonGroup.add(seven);
      buttonPanel.add(eight);      this.buttonGroup.add(eight);
      buttonPanel.add(nine);       this.buttonGroup.add(nine);
      buttonPanel.add(minus);      this.buttonGroup.add(minus);
      buttonPanel.add(four);       this.buttonGroup.add(four);
      buttonPanel.add(five);       this.buttonGroup.add(five);
      buttonPanel.add(six);        this.buttonGroup.add(six);
      buttonPanel.add(multiply);   this.buttonGroup.add(multiply);
      buttonPanel.add(one);        this.buttonGroup.add(one);
      buttonPanel.add(two);        this.buttonGroup.add(two);
      buttonPanel.add(three);      this.buttonGroup.add(three);
      buttonPanel.add(divide);     this.buttonGroup.add(divide);
      buttonPanel.add(zero);       this.buttonGroup.add(zero);
      buttonPanel.add(slash);      this.buttonGroup.add(slash);
      buttonPanel.add(space);      this.buttonGroup.add(space);
      buttonPanel.add(stack);      this.buttonGroup.add(stack);

      return buttonPanel;
   }

   /*****************************************************************
   Set up the Menu Bar for the gui (not much in the menu bar)
   *****************************************************************/
   private JMenuBar setUpMenuBar(){
      JMenuBar jmenuBar = new JMenuBar();
      
      this.menuItemGroup = new ButtonGroup();
      //Set up the File menu
      jmenuBar.add(this.setUpFileMenu());
      //Set up the Help menu
      jmenuBar.add(this.setUpHelpMenu());

      return jmenuBar;
   }
   
   /*****************************************************************
   Set up the File menu for the gui
   *****************************************************************/
   private JMenu setUpFileMenu(){
      JMenu file = new JMenu("File");
      file.setMnemonic(KeyEvent.VK_F);
      
      //Clear Menu Item
      JMenuItem clear = new JMenuItem("Clear",'C');
      clear.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,
                                              InputEvent.CTRL_MASK));
      //ChangeSign Menu Item
      JMenuItem changeSign = new JMenuItem("Change Sign", 'S');
      changeSign.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
                                              InputEvent.CTRL_MASK));
      //RollDown Menu Item
      JMenuItem rollDown = new JMenuItem("Roll Down", 'R');
      //Exchange Menu Item
      JMenuItem exchange = new JMenuItem("Exchange", 'E');
      exchange.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
                                              InputEvent.CTRL_MASK));
      //Reciprocal Menu Item
      JMenuItem reciprocal = new JMenuItem("Reciprocal", 'I');
      reciprocal.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,
                                              InputEvent.CTRL_MASK));
      
      //Quit Menu Item
      JMenuItem quit = new JMenuItem("Quit", 'Q');
      quit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
                                              InputEvent.CTRL_MASK));
      
      file.add(clear);      this.menuItemGroup.add(clear);
      file.add(changeSign); this.menuItemGroup.add(changeSign);
      file.addSeparator();
      file.add(rollDown);   this.menuItemGroup.add(rollDown);
      file.add(exchange);   this.menuItemGroup.add(exchange);
      file.addSeparator();
      file.add(reciprocal); this.menuItemGroup.add(reciprocal);
      file.addSeparator();
      file.add(quit);       this.menuItemGroup.add(quit);
      
      return file;
   }
   
   /*****************************************************************
   Set up the Help menu for the gui
   *****************************************************************/
   private JMenu setUpHelpMenu(){
      JMenu help = new JMenu("Help");
      help.setMnemonic(KeyEvent.VK_H);
      
      //Help Menu Item
      JMenuItem helpItem = new JMenuItem("Help", 'H');
      helpItem.setAccelerator(
                            KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0)
      );
      //Keyboard Help Menu Item
      JMenuItem keyboardHelpItem=new JMenuItem("Keyboard Help",'K');
      //About Menu Item
      JMenuItem about = new JMenuItem("About", 'A');
      about.setAccelerator(
                            KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0)
      );
      //Add the Menu Items to the Help Menu
      help.add(helpItem);        
      help.add(keyboardHelpItem);
      help.addSeparator();
      help.add(about);

      this.menuItemGroup.add(helpItem);
      this.menuItemGroup.add(keyboardHelpItem);
      this.menuItemGroup.add(about);

      return help;
   }

   /*****************************************************************
   Set up the Radio Button Panel
   *****************************************************************/
   private JPanel setUpRBPanel(){
      JPanel rbPanel = new JPanel();

      rbPanel.setBorder(BorderFactory.createEtchedBorder());
      //Instantiate the Button Group
      radioButtonGroup = new ButtonGroup();      
      //Instantiate the JRadioButtons
      JRadioButton proper   = new JRadioButton("Proper", true);
      JRadioButton improper = new JRadioButton("Improper", false);     
      //Add Radio Buttons to the Button Group
      this.radioButtonGroup.add(proper);
      this.radioButtonGroup.add(improper);     
      //Add Radio Buttons to the Panel
      rbPanel.add(proper);
      rbPanel.add(improper);

      return rbPanel;
   }
   
   /*****************************************************************
   Set up the stackFrame instance, but don't display until requested
   and update as needed.
   *****************************************************************/
   private void setUpStackFrame(){
      final int CURRENT_WIDTH  = 160;
      final int CURRENT_HEIGHT = 250;
      
      this.stackFrame = new GenericJInteractionFrame("Stack Display");
      this.stackTextArea = new JTextArea();
      Container contentPane = stackFrame.getContentPane();
      Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
      
      contentPane.add(stackTextArea, BorderLayout.CENTER);
      this.stackFrame.setSize(CURRENT_WIDTH, CURRENT_HEIGHT);
      this.stackFrame.setLocation(
         (int)(dim.getWidth()/2  + WIDTH/2),
         (int)(dim.getHeight()/2 + HEIGHT/2 - CURRENT_HEIGHT)
      );      
      this.stackTextArea.setEditable(false);
      this.stackFrame.setResizable(false);
      this.stackFrame.setVisible(false);
   }
   
   /*****************************************************************
   If a FractionException occurred, indicate that by showing the
   appropriate error dialog (or one as needed).
   *****************************************************************/
   private void showErrorDialog(int error){
      String exception = new String("Fraction error!!\n");
      String display = new String("Fraction error");
      if(error == FractionException.NO_NUMERATOR){
         exception += "Please enter an appropriate numerator.";
      }
      else if(error == FractionException.NO_DENOMINATOR){
         exception += "Please enter an appropriate denominator.";
      }
      else if(error == FractionException.NO_FRACTION){
         exception += "Please enter a legitimate fraction.";
         this.selectRequestTextField();
         //Since this is not a legitimate fracition, the whole
         //thing needs to be re-entered, go ahead and reset the
         //Slash ("/") button
         this.setSlashPressed(false);
      }
      else if(error == FractionException.ZERO_DENOMINATOR){
         exception += "Undefined:  can't have a zero in the";
         exception += " denominator.";
         this.selectRequestTextField();
         //Since this is not a legitimate fracition, the whole
         //thing needs to be re-entered, go ahead and reset the
         //Slash ("/") button
         this.setSlashPressed(false);
      }
      JOptionPane.showMessageDialog(this, exception, display,
                                    JOptionPane.ERROR_MESSAGE);
   }
}
