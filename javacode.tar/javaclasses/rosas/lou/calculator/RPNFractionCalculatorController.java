/********************************************************************
The RPN Fraction Calculator Application.
Copyright (C) 2007 Lou Rosas

This file is part of RPNFractionCalculator
RPNFractionCalculator is free software; you can redistribute it
and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

RPNFractionCalculator is distributed in the hope that it will be
useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
package rosas.lou.calculator;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import rosas.lou.*;
import rosas.lou.calculator.*;

/********************************************************************
The RPNFractionCalculatorController class by Lou Rosas.  This class
contains all the attributes and operations related to controlling
user input related to the RPNFractionCalculatorView.
********************************************************************/
public class RPNFractionCalculatorController
implements ActionListener, KeyListener, ItemListener{
   private Observable calculator; //RPNFractionCalculator class
   private Observer   view;       //RPNFractionCalculatorView class
   private String     currentString;
   private boolean    slashPressed;
   
   /***********************Public Methods***************************/
   /*****************************************************************
   Constructor of no arguments
   *****************************************************************/
   public RPNFractionCalculatorController(){}
   
   /*****************************************************************
   Constructor accepting an RPNFractionCalculatorView attribute
   *****************************************************************/
   public RPNFractionCalculatorController(Observer view){
      this.view = view;
      //Instantiate the model
      calculator = new RPNFractionCalculator(view);
   }
   
   /*****************************************************************
   Implementation of the actionPerformed method from the
   ActionListener Interface.
   *****************************************************************/
   public void actionPerformed(ActionEvent e){
      Object o = e.getSource();
      if(o instanceof JTextField){
         this.handleTextField((JTextField)o);
      }
      else if(o instanceof JButton){
         this.handleButtonItem((JButton)o);
      }
      else if(o instanceof JMenuItem){
         this.handleMenuItem((JMenuItem)o);
      }
   }
   
   /*****************************************************************
   Implementation of the keyPressed method from the KeyListener
   Interface.
   *****************************************************************/
   public void keyPressed(KeyEvent k){
      Object object  = k.getSource();
      char   keyChar = k.getKeyChar();
      int    keyCode = k.getKeyCode();
      RPNFractionCalculatorView theView;
      theView = (RPNFractionCalculatorView)this.view;

      if(object instanceof JButton){
         if(keyCode == KeyEvent.VK_ENTER){
            JButton button = (JButton)object;
            button.doClick();
         }
      }
      else if(object instanceof JTextField){
         //All the numbers and '/'
         if(keyChar >= '0' && keyChar <= '9' || keyChar == '/'){
            this.handleKeyPressedNumbersAndSlash(keyChar);
         }
         //The arithmetic operations
         else if(keyChar == '+' || keyChar == '*' ||
                 keyChar == '-' || keyChar == 'd' ||
                 keyChar == 'D'){
            this.handleKeyPressedArithmeticOperations(keyChar);
         }
         //Clear button
         else if(keyChar == 'c' || keyChar == 'C'){
            char commandChar = Character.toUpperCase(keyChar);
            String buttonText = new String(commandChar + "");
            theView.clickButton(buttonText);
         }
         //Exchange button
         else if(keyChar == 'e' || keyChar == 'E'){
            String buttonText = new String("x<->y");
            theView.clickButton(buttonText);
         }
         //Reciprocal (inverse) button
         else if(keyChar == 'i' || keyChar == 'I'){
            String buttonText = new String("1/x");
            theView.clickButton(buttonText);
         }
         //Rolldown button
         else if(keyChar == 'r' || keyChar == 'R' ||
                 keyCode == KeyEvent.VK_DOWN){
            String buttonText = new String("rdn");
            theView.clickButton(buttonText);
         }
         //Change sign button
         else if(keyCode == KeyEvent.VK_F3){
            String buttonText = new String("(-)");
            theView.clickButton(buttonText);
         }
         //Stack display button
         else if(keyCode == KeyEvent.VK_F6){
            String buttonText = new String("stack");
            theView.clickButton(buttonText);
         }
         //Backspace button
         else if(keyCode == KeyEvent.VK_BACK_SPACE){
            String buttonText = new String("bkspc");
            theView.clickButton(buttonText);
         }
         //Space button
         else if(keyCode == KeyEvent.VK_SPACE){
            String buttonText = new String("Spc");
            theView.clickButton(buttonText);
         }
      }
   }
   
   /*****************************************************************
   Implementation of the keyReleased method from the KeyListener
   Interface.
   *****************************************************************/
   public void keyReleased(KeyEvent k){}
   
   /*****************************************************************
   Implementation of the keyPressed method from the KeyListener
   Interface.
   *****************************************************************/
   public void keyTyped(KeyEvent k){}
   
   /*****************************************************************
   Implementation of the itemStateChanged method from the
   ItemListener Interface.
   *****************************************************************/
   public void itemStateChanged(ItemEvent ie){
      RPNFractionCalculator model;
      model = (RPNFractionCalculator)calculator;
      if(ie.getItem() instanceof JRadioButton){
         int stateChange = ie.getStateChange();
         if(stateChange == ItemEvent.SELECTED){
            JRadioButton jrb = (JRadioButton)ie.getItem();
            String rbString  = jrb.getText();
            if(rbString.equals("Proper")){
               //Set the display mode for the fractions to proper
               model.setFractionDisplay(true);
            }
            else{
               //Set the display mode for the fractions to improper
               model.setFractionDisplay(false);
            }
         }
      }
   }
   
   /**********************Private Methods***************************/
   /*****************************************************************
   Handle the ActionEvents emanating from a JMenuItem selection
   *****************************************************************/
   private void handleMenuItem(JMenuItem m){
      String menuText = m.getText();
      //Handle the "Quit" menu item
      //Tell the calculator to quit
      if(menuText.equals("Quit"))
         ((RPNFractionCalculator)calculator).quit();
      //Handle the "Help" menu item
      else if(menuText.equals("Help"))
         ((RPNFractionCalculatorView)view).displayHelp();
      else if(menuText.equals("Keyboard Help"))
         ((RPNFractionCalculatorView)view).displayKeyboardHelp();
      //Handle the "About" menu item
      else if(menuText.equals("About"))
         ((RPNFractionCalculatorView)view).displayAbout();
      //Handle the Clear Menu Item
      else if(menuText.equals("Clear"))
         ((RPNFractionCalculator)calculator).clearTopRegister();
      //Handle the Change Sign Menu Item (-)
      else if(menuText.equals("Change Sign"))
         this.handleChangeSignButton();
      //Handle the Roll Down Menu Item (rdn)
      else if(menuText.equals("Roll Down")){
         RPNFractionCalculatorView theView;
         theView = (RPNFractionCalculatorView)this.view;
         try{
            Fraction f = theView.grabFraction();
            ((RPNFractionCalculator)calculator).rollDown(f);
         }
         catch(NullPointerException npe){}
      }
      //Handle the Exchange Menu Item (x<-->y)
      else if(menuText.equals("Exchange"))
         this.handleExchange();
      //Handle the Reciprocal (Inverse) Menu Time (1/x)
      else if(menuText.equals("Reciprocal"))
         //Handle the arithmetic operation by passing in the correct
         //String
         this.handleArithmeticOperations("1/x");
   }
   
   /*****************************************************************
   Handle the ActionEvents emanating from a JButton press
   *****************************************************************/
   private void handleButtonItem(JButton b){
      String buttonText = b.getText();
      char firstChar = buttonText.charAt(0);
      if(buttonText.equals("1/x")){
         this.handleArithmeticOperations(buttonText);
      }
      else if(buttonText.equals("(-)")){
         this.handleChangeSignButton();
      }
      //Handle the '0'-'9' and the '/'
      else if(firstChar >= '0' && firstChar <= '9' ||
              firstChar == '/'){
         this.handleNumbersAndSlash(firstChar);
      }
      else if(buttonText.equals("Enter")){
         this.handleEnterPress();
      }
      else if(buttonText.equals("stack")){
         //Send the fraction stack to the view for display
         ((RPNFractionCalculator)calculator).sendStack();
      }
      else if(buttonText.equals("C")){
         ((RPNFractionCalculator)calculator).clearTopRegister();
      }
      else if(buttonText.equals("rdn")){
         RPNFractionCalculatorView theView;
         theView = (RPNFractionCalculatorView)view;
         try{
            Fraction f = theView.grabFraction();
            ((RPNFractionCalculator)calculator).rollDown(f);
         }
         catch(NullPointerException npe){}
      }
      else if(buttonText.equals("+") || buttonText.equals("-")   ||
              buttonText.equals("*") || buttonText.equals("Div")){
         this.handleArithmeticOperations(buttonText);
      }
      else if(buttonText.equals("x<->y")){
         //Handle the exchange of the x and y registers
         this.handleExchange();
      }
      else if(buttonText.equals("bkspc")){
         this.handleBackspace();
      }
      //Put spaces in the text field
      else if(buttonText.equals("Spc")){
         this.handleSpace();
      }
   }

   /*****************************************************************
   Handle every and all arithmetic operations.  This includes:
   add(+), subtract(-), multiply(*), divide(Div), invert(1/x)
   Catches:  NullPointerException
   *****************************************************************/
   private void handleArithmeticOperations(String buttonText){
      RPNFractionCalculatorView  theView;
      RPNFractionCalculator      model;
      theView  = (RPNFractionCalculatorView)view;
      model    = (RPNFractionCalculator)calculator;

      try{
         if(buttonText.equals("+")){
            model.add(theView.grabFraction());
         }
         else if(buttonText.equals("-")){
            model.subtract(theView.grabFraction());
         }
         else if(buttonText.equals("*")){
            model.multiply(theView.grabFraction());
         }
         else if(buttonText.equals("Div")){
            model.divide(theView.grabFraction());
         }
         else{
            model.invertFraction(theView.grabFraction());
         }
      }
      catch(NullPointerException npe){}
   }

   /*****************************************************************
   Handle the "bkspc"--the backspace button being pressed.
   *****************************************************************/
   private void handleBackspace(){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator     model;
      theView = (RPNFractionCalculatorView)this.view;
      model   = (RPNFractionCalculator)this.calculator;
      char character;
      try{
         String s = new String(theView.getText());
         //Grab the last character in the String
         character = s.charAt(s.length() - 1);
         //Set the string to the string without the last character
         s = new String(s.substring(0, s.length() - 1));
         theView.setText(s);
         if(character == '/'){
            //If the last character "eaten" is the "/", enable the
            //"/" button for the use of entering denominators in
            //fractions.
            theView.setSlashPressed(false);
         }
         theView.requestTextField();
      }
      catch(IndexOutOfBoundsException obe){
         //When the string is all gone, set the display to "0/1"
         String s = new String("0/1");
         theView.setText(s);
         theView.requestTextField();
      }
   }

   /*****************************************************************
   Handle the event of the "(-)" button being pressed.
   *****************************************************************/
   private void handleChangeSignButton(){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator     model;

      theView = (RPNFractionCalculatorView)view;
      model   = (RPNFractionCalculator)calculator; 
      String display    = theView.getText();
      String newDisplay = new String();
      boolean isNumZero = false;

      if(display.charAt(0) == '0'){
         isNumZero = true;
      }
      if((display.length()) > 0 && (display.charAt(0) == '-')){
         //Undisplay the '-' character
         newDisplay = new String(display.substring(1));
      }
      else{
         newDisplay = new String("-" + display);
      }
      if(!isNumZero){
         theView.setText(newDisplay);
         //Need to indicate a new number has been entered
         model.setNumberPressed();
      }
      theView.requestTextField();
   }

   /*****************************************************************
   Handle the event of the "Enter" button being pressed.
   Catches:  NullPointerException if things go bad.
   *****************************************************************/
   private void handleEnterPress(){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator     model;
      theView = (RPNFractionCalculatorView)this.view;
      model   = (RPNFractionCalculator)this.calculator;
      Fraction theFraction = new Fraction();

      try{
         //Get the FractionObject from the display
         theFraction = theView.grabFraction();
         model.enter(theFraction);
      }
      catch(NullPointerException npe){}
   }

   /*****************************************************************
   Handle the "x<->y" button press.
   *****************************************************************/
   private void handleExchange(){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator    model;
      theView = (RPNFractionCalculatorView)this.view;
      model   = (RPNFractionCalculator)this.calculator;
      try{
         model.exchange(theView.grabFraction());
      }
      catch(NullPointerException npe){}
   }

   /*****************************************************************
   Handle the numbers and '/' from a KeyEvent by messaging the View
   to click the appropriate button.
   *****************************************************************/
   private void handleKeyPressedNumbersAndSlash(char keyChar){
      RPNFractionCalculatorView theView;
      theView = (RPNFractionCalculatorView)this.view;
      String buttonText = new String(keyChar + "");
      theView.clickButton(buttonText);
   }

   /*****************************************************************
   Handle the appropriate arithmetic operataions from a KeyEvent by
   messaging the View to click the appropriate button.  Since the '/'
   is taken, use the 'd' or 'D' for division in a fraction
   calculator.
   *****************************************************************/
   private void handleKeyPressedArithmeticOperations(char keyChar){
      RPNFractionCalculatorView theView;
      theView = (RPNFractionCalculatorView)this.view;
      String buttonText = new String(keyChar + "");
      switch(keyChar){
         case '+' :
         case '-' :
         case '*' :
            theView.clickButton(buttonText);
            break;
	      case 'd' :
         case 'D' :
            buttonText = new String("Div");
	         theView.clickButton(buttonText);
	         break;
	      default:  ;
      }
   }

   /*****************************************************************
   Handle the numbers and '/' by messaging the view to place on
   the text field as appropriate.
   *****************************************************************/
   private void handleNumbersAndSlash(char character){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator     model;
      theView = (RPNFractionCalculatorView)this.view;
      model   = (RPNFractionCalculator)this.calculator;
      try{
         String s = new String(theView.getSelectedText());
         theView.setText("" + character);
         theView.setSlashPressed(false);
         model.setNumberPressed();
      }
      catch(NullPointerException npe){
         theView.setText(theView.getText() + character);
         model.setNumberPressed();
      }
      if(character == '/')
         theView.setSlashPressed(true);
   }
   
   /*****************************************************************
   Handle the ActionEvent emanationg from the TextField.  The only
   ActionEvent that is fired from a TextField (that is of any
   concern) the the "ENTER" button press when the TextField has
   focus.
   *****************************************************************/
   private void handleTextField(JTextField tf){
      //Message the view to "click" the "Enter" button
      ((RPNFractionCalculatorView)view).clickButton("Enter");
   }

   /*****************************************************************
   Handle the "Spc" button press.  This will put spaces in the text
   field.  This is for handleling proper fractions:  a b/c.
   Multiple spaces can be placed anywhere in the text field.  In
   other words, the fraction COULD be rendered unreadable-->possibly
   an exception will be thrown.  There is no guarantee how the
   calcualtor will act if this button is not used properly.
   *****************************************************************/
   private void handleSpace(){
      RPNFractionCalculatorView theView;
      RPNFractionCalculator     model;
      theView  = (RPNFractionCalculatorView)this.view;
      model    = (RPNFractionCalculator)this.calculator;
      try{
         theView.setText(theView.getText() + " ");
         theView.requestTextField();
      }
      catch(NullPointerException npe){
         theView.setText(" ");
         theView.requestTextField();
      }
   }
}
