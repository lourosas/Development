/********************************************************************
The RPN Fraction Calculator Application.
Copyright (C) 2007 Lou Rosas

This file is part of RPNFractionCalculator
RPNFractionCalculator is free software; you can redistribute it
and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

RPNFractionCalculator is distributed in the hope that it will be
useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
package rosas.lou.calculator;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import rosas.lou.*;
import rosas.lou.calculator.*;

/********************************************************************
The RPN Fraction Calculator class by Lou Rosas.  This class contains
all the attributes and methods related to a Typical RPN Calculator
as well as the functionality needed for arithimetic opperations for
a fractions.  This class essentially emulates an RPN (Reverse Polish
Notation) calcualtor that handles fractions.
Unlike algebraic notation, RPN enters the number FIRST, then the
operation:
i.e.  Algebraic:  a+b
      RPN: a,b +
An RPN calculator uses the stack principle of number manipulation,
and thus has no need for 1)The "=" sign, 2)Parenthetical expresions.
The stack has a minimum of four registers (although, it could be
deeper, but not needed)-->The registers indicate the size of the
stack. The registers are named in the following way:
x:  the top register and the register displayed
y:  the register below
z:
t:  the final register
Numbers are entered by either pressing the <Enter> button, or a
mathematical operation.
If the <Enter> button is pressed, the number is entered in both the
x and y register (the highest two)
i.e.
1/3 <Enter> results:  x: 1/3
                      y: 1/3
If another number is entered, that number resides in the top register
ONLY i.e. entering 1/5 results x: 1/5
                               y: 1/3.
                               
An operation pops the number off the x, y registers of the stack,
placing the result on the x register
i.e. + results:  x: 8/15
                 y:
                 z:
                 t:
Since this is a software emulation of a physical calculator, certain
design descisions were made to best accomodate and emulate an RPN
calculator.  But as a result, simply enterering a number in the
display DOES NOT guarantee the number is entered in the x-register.
rather, either the <Enter> button needs to be pressed, or another
mathematical operation needs to be completed to guarantee the number
being displayed is in the x-register (or the result of the operation
is diplayed in the x-register.
********************************************************************/
public class RPNFractionCalculator extends Observable
implements Calculator{
   private static final short ADD      = 0x1;
   private static final short SUBTRACT = 0x2;
   private static final short MULTIPLY = 0x4;
   private static final short DIVIDE   = 0x8;
   //The Stack Object holding the fractions
   private Stack fractionStack;
   //The Answer state boolean.
   private boolean numberState;

   /********************Public Methods and Constructors*************/
   /*****************************************************************
   Constructor of no arguments
   *****************************************************************/
   public RPNFractionCalculator(){
      this.fractionStack = new Stack();
      this.initializeStack();
      this.setNumberState(false);
   }

   /*****************************************************************
   Constructor Accepting the Observer.  Register the observer
   *****************************************************************/
   public RPNFractionCalculator(Observer observer){
      this.fractionStack = new Stack();
      this.addObserver(observer);
      this.initializeStack();
      this.setNumberState(false);
   }
   
   /****************************************************************
   Implementing the add method from the Calculator interface.
   ****************************************************************/
   public void add(Object toAdd){
      if(this.getNumberState()){
         Stack stack = this.getStack();
         stack.push(toAdd);
      }
      this.performOperation(ADD);
   }
   
   /*****************************************************************
   Implementing the subtract method from the Calculator interface.
   *****************************************************************/
   public void subtract(Object toSubtract){
      if(this.getNumberState()){
         Stack stack = this.getStack();
         stack.push(toSubtract);
      }
      this.performOperation(SUBTRACT);
   }
   
   /*****************************************************************
   Implementing the multiply method from the Calculator interface.
   *****************************************************************/
   public void multiply(Object toMultiply){
      if(this.getNumberState()){
         Stack stack = this.getStack();
         stack.push(toMultiply);
      }
      this.performOperation(MULTIPLY);
   }
   
   /*****************************************************************
   Implementing the divide method from the Calculator interface.
   *****************************************************************/
   public void divide(Object toDivide){
      if(this.getNumberState()){
         Stack stack = this.getStack();
         stack.push(toDivide);
      }
      this.performOperation(DIVIDE);
   }

   /*****************************************************************
   Clear the top register (the display register) of the stack.
   By clearing, replacing its contents with 0/1 (the zero-fraction)
   *****************************************************************/
   public void clearTopRegister(){
      this.clearDisplay();
   }
   
   /*****************************************************************
   Enter a fraction into the stack.  This places the fraction in:
   1)The display register (the x-register)
   2)The next register (the y-register)
   Then notify the observers of the change.
   *****************************************************************/
   public void enter(Fraction fraction){
      //Get the local Stack
      Stack stack = this.getStack();
      //If legitimate fraciton, push onto stack!
      if(fraction.getNumerator() != 0){
         stack.push(fraction);
         this.setNumberState(false);
         //Now update the observers
         this.setChanged();
         this.notifyObservers(stack.peek());
         this.clearChanged();
      }
   }
   
   /*****************************************************************
   Exchage the Fractions in the x and y registers.
   *****************************************************************/
   public void exchange(Fraction exchange){
      //message exchageRegisters(...)
      this.exchangeRegisters(exchange);
   }
   
   /*****************************************************************
   Invert the Fraction:  a/b-->b/a..
   *****************************************************************/
   public void invertFraction(Fraction toInvert){
      this.invertTheFraction(toInvert);
   }
   
   /*****************************************************************
   Quit the application
   *****************************************************************/
   public void quit(){
      System.out.println("The RPN Calculator is quitting");
      System.exit(0);
   }
   
   /*****************************************************************
   "Roll" the contents of the registers.
   i.e.  x: 1/3     becomes:  x:  3/1
         y: 1/2               y:  1/3
         z: 1/12              z:  1/2
         t: 3/1               t:  1/12
   The replacement becomes:  x->y, y->z, z->t, t->a.
   *****************************************************************/
   public void rollDown(Fraction f){
      if(this.getNumberState()){
         Stack stack = this.getStack();
         stack.push(f);
      }
      this.rollStack();
   }
   
   /*****************************************************************
   Send a copy of the stack to the Observers (this is done ONLY for
   display)
   *****************************************************************/
   public void sendStack(){
      Stack stack           = new Stack();
      Stack calculatorStack = this.getStack();
      Enumeration e = calculatorStack.elements();
      while(e.hasMoreElements()){
         stack.push(e.nextElement());
      }
      this.setChanged();
      this.notifyObservers(stack);
      this.clearChanged();
   }
   
   /*****************************************************************
   This method is called by the controller to indicate the pressing
   event of a number or the slash ('/').
   *****************************************************************/
   public void setNumberPressed(){
      this.setNumberState(true);
   }
   
   /*****************************************************************
   Set the display state for every fraction in the stack.
   *****************************************************************/
   public void setFractionDisplay(boolean displayState){
      this.setFractionDisplayState(displayState);
   }
   
   /***********************Private Methods**************************/
   /*****************************************************************
   Clear the display of the top register (the x-register)
   *****************************************************************/
   private void clearDisplay(){
      Stack stack    = this.getStack();
      boolean toPush = false;
      try{
         if(!this.getNumberState()){
            stack.pop();
         }
         Fraction checkFraction = (Fraction)stack.peek();
         if(checkFraction.getNumerator() != 0){
            toPush = true;
         }
      }
      catch(EmptyStackException ese){
         toPush = true;
      }
      finally{
         Fraction returnFraction = new Fraction();
         if(toPush){
            stack.push(returnFraction);
         }
         this.setNumberState(false);
         this.setChanged();
         this.notifyObservers(returnFraction);
         this.clearChanged();
      }
   }
   
   /*****************************************************************
   Exchange the Fractions in the x and y registers.
   *****************************************************************/
   private void exchangeRegisters(Fraction exchange){
      Stack stack         = this.getStack();
      Fraction fraction_x = new Fraction();
      Fraction fraction_y = new Fraction();
      
      try{
         if(!this.getNumberState()){
            fraction_y = (Fraction)stack.pop();
         }
         else{
            fraction_y = exchange;
         }
         fraction_x = (Fraction)stack.pop();
      }
      /*IF there is only one Fraciton on the stack, set either
        fraction_x or fraction_y to 0.  This is already done in
        the initialization!!!*/
      catch(EmptyStackException ese){
      }
      finally{
         //Exchange the Fractions by placing BACK onto the stack
         stack.push(fraction_y);
         stack.push(fraction_x);
         this.setNumberState(false);
         this.setChanged();
         this.notifyObservers(stack.peek());
         this.clearChanged();
      }
   }

   /*****************************************************************
   Initialize the Stack to fractional zero (0/1) for the x register.
   *****************************************************************/
   private void initializeStack(){
      Stack stack = this.getStack();
      stack.push(new Fraction());
      this.setChanged();
      this.notifyObservers(stack.peek());
      this.clearChanged();
   }
   
   /*****************************************************************
   Invert the Fraction:  a/b-->b/a.  If there are any Fraction
   Exceptions, notify the Observers.
   *****************************************************************/
   private void invertTheFraction(Fraction toInvert){
      Object   answer           = new Object();
      Stack    stack            = this.getStack();
      Fraction originalFraction = new Fraction();
      if(!this.getNumberState()){
         originalFraction = (Fraction)stack.pop();
      }
      else{
         originalFraction = toInvert;
      }
      try{
         answer = originalFraction.getInverse();
         stack.push(answer);
         Fraction printFraction = (Fraction)answer;
      }
      catch(FractionException fe){
         fe.printStackTrace();
         if(!this.getNumberState()){
            stack.push(originalFraction);
         }
         answer = fe;
      }
      finally{
         //Upon an exception, the Stack should be reflected in the
         //Display (as always)
         if(this.getNumberState() && !(answer instanceof Fraction)){
            this.setChanged();
            this.notifyObservers(stack.peek());
            this.clearChanged();
         }
         this.setNumberState(false);
         this.setChanged();
         this.notifyObservers(answer);
         this.clearChanged();
      }
   }
   
   /*****************************************************************
   Get the current answerState.  This determines in clearing the
   x-register what to do--either push the x-register and then clear
   or just clear.
   *****************************************************************/
   private boolean getNumberState(){
      return this.numberState;
   }
   /*****************************************************************
   Return the local Stack instance
   *****************************************************************/
   private Stack getStack(){
      return this.fractionStack;
   }
   
   /*****************************************************************
   Perform the operation requested:  ADD, SUBTRACT, MULTIPLY, DIVIDE
   *****************************************************************/
   private void performOperation(short operation){
      Stack    stack      = this.getStack();
      Fraction fraction_x = new Fraction();
      Fraction fraction_y = new Fraction();
      Object   answer     = new Object();
      try{
         //Pop both Fraction off the Stack
         fraction_x = (Fraction)stack.pop();
         fraction_y = (Fraction)stack.pop();
      }
      //Since fraction_y is already set up to be 0/1, don't do
      //anything
      catch(EmptyStackException ese){
      }
      finally{
         try{
            switch(operation){
               case ADD: 
                  answer = fraction_y.add(fraction_x);
                  break;
               case SUBTRACT:
                  answer = fraction_y.subtract(fraction_x);
                  break;
               case MULTIPLY:
                  answer = fraction_y.multiply(fraction_x);
                  break;
               case DIVIDE:
                  answer = fraction_y.divide(fraction_x);
                  break;
               /*Should never get here, but if not one of the
                 operations above,  just go ahead and push both
                 fractions back onto the Stack.*/
               default:
                  stack.push(fraction_y);
                  answer = fraction_x;
            }
            stack.push(answer);
         }
         catch(FractionException fe){
            fe.printStackTrace();
            stack.push(fraction_y);
            answer = fe;
         }
         finally{
            //Set the number state to false
            this.setNumberState(false);
            //Update the Observers
            this.setChanged();
            this.notifyObservers(answer);
            this.clearChanged();
         }
      }
   }
   
   /*****************************************************************
   Roll the contents of the stack--See the comments in the rollDown
   method.
   *****************************************************************/
   private void rollStack(){
      Stack stack       = this.getStack();
      Fraction fraction = new Fraction();
      try{
         fraction = (Fraction)stack.pop();
         //Put on the bottom of the Stack
         stack.insertElementAt(fraction, 0);
      }
      catch(EmptyStackException ese){
         //If empty, just push the fraction back onto the Stack
         stack.push(fraction);
      }
      finally{
         this.setNumberState(false);
         //Update the observers
         this.setChanged();
         this.notifyObservers(stack.peek());
         this.clearChanged();
      }
   }
   
   /*****************************************************************
   Set the display state for every fraction in the stack.  Only
   tell the View to update if a new fraction is not being entered
   at the time (via the getNumberedState() boolean return).
   *****************************************************************/
   private void setFractionDisplayState(boolean fracDisplayState){
      Stack stack   = this.getStack();
      Enumeration e = stack.elements();
      String notifyString = new String();
      while(e.hasMoreElements()){
         Fraction f = (Fraction)e.nextElement();
         f.setDisplayState(fracDisplayState);
         if(fracDisplayState)
            notifyString = new String("fraction display state-true");
         else
            notifyString = new String("fraction display state-false");
         //Notify the observers of the change--sending
         //the new display state data.
         this.setChanged();
         this.notifyObservers(notifyString);
         this.clearChanged();
         //Check the numbered state, if no fraction is currently
         //being entered (the x-register is not about to change)
         //inform the observers of the change in the display state
         //in the x-register.
         if(!this.getNumberState()){
            this.setChanged();
            try{
               this.notifyObservers(stack.peek());
            }
            catch(EmptyStackException ese){}
            finally{
               this.clearChanged();
            }
         }
      }
   }
   
   /*****************************************************************
   Set the number state boolean value-->as needed.  This determines
   if an answer has been determined.
   *****************************************************************/
   private void setNumberState(boolean state){
      this.numberState = state;
   }
}
