/***
 *
 **/

package rosas.lou.clock;

import java.lang.*;
import java.util.*;
import rosas.lou.clock.TimeFormater;
import rosas.lou.clock.ClockState;

public interface TimeListener{
   public void update(ClockState clockState);
   public void update(Object o);
   public void update(TimeFormater timeFormater);
   public void update(TimeFormater tf, ClockState cs);
}
