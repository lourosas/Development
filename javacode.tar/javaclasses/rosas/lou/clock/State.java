/***/
package rosas.lou.clock;

import java.util.*;
import java.lang.*;
import rosas.lou.clock.*;

public enum State{START, STOP, RESET, RUN, LAP, UNKNOWN}
