/**
 * **/
package rosas.lou.clock;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import rosas.lou.*;
import rosas.lou.clock.TimeListener;
import rosas.lou.clock.StopWatch;

/**
 * */
public class StopWatchController implements ActionListener,
KeyListener{
   private static final short QUERYTIME = 1000;
   private StopWatch stopWatch;

   /**
 * Constructor of no arguments
 * */
   public StopWatchController(){
      this(QUERYTIME);
   }

   /**
 * Constructor taking the Query Time as an argument...
 * */
   public StopWatchController(short queryTime){
      this.stopWatch = new StopWatch();
      //Now, need to start the StopWatch
      Thread t = new Thread(this.stopWatch);
      t.start();
   }

   /**
 * Implementation of the actionPerformed method from the
 * ActionListener Interface
 * */
   public void actionPerformed(ActionEvent e){
      if(e.getSource() instanceof JButton){
         this.handleJButton((JButton)e.getSource());
      }
      else if(e.getSource() instanceof JMenuItem){
         this.handleJMenuItem((JMenuItem)e.getSource());
      }
   }

   /**
 *
 * */
   public void addTimeListenerToModel(TimeListener tl){
      this.stopWatch.addTimeListener(tl);
   }

   /**
 * Implementation of the keyPressed method from the KeyListener
 * Interface
 * */
   public void keyPressed(KeyEvent k){}

   /**
 *
 * */
   public void keyReleased(KeyEvent k){}

   /**
 * Implementation of the keyTyped method from the KeyListener
 * Interface
 * */
   public void keyTyped(KeyEvent k){}

   /**
 * */
   public void killTheStopWatch(){
      this.stopWatch.kill();
   }

   ////////////////////////////Private Methods////////////////////////
   //
   //
   //
   private void handleJButton(JButton jb){
      if(jb.getActionCommand().equals("Start")){
         this.stopWatch.start();
      }
      else if(jb.getActionCommand().equals("Stop")){
         this.stopWatch.stop();
      }
   }

   //
   //
   //
   private void handleJMenuItem(JMenuItem jmi){
      if(jmi.getActionCommand().equals("Quit")){
         this.killTheStopWatch();
         System.exit(0);
      }
      else if(jmi.getActionCommand().equals("Start")){
         this.stopWatch.start();
      }
      else if(jmi.getActionCommand().equals("Stop")){
         this.stopWatch.stop();
      }
   }
}
