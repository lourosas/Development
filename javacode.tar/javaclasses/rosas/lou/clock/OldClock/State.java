package rosas.lou.clock;

import java.util.*;
import java.lang.*;

public enum State{STOP, START, RESET, LAP};
