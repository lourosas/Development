/***
 *
 * */
package rosas.lou.clock;

import java.lang.*;
import java.util.*;
import rosas.lou.clock.*;

public class ClockState{
   private State state;
   {
      state = State.UNKNOWN;
   }

   /**
 * */
   public ClockState(){}

   /**
 * */
   public ClockState(State currentState){
      this.setState(currentState);
   }

   public State getState(){ return this.state; }

   public void setState(State currentState){
      this.state = currentState;
   }
}
