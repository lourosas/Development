/***
 *This needs to be fast and accurate
 * */
package rosas.lou.clock;

import java.lang.*;
import java.util.*;
import java.text.*;
import rosas.lou.clock.*;

public class TimeFormater{
   private static final short HOURS_IN_DAY = 24;
   private static final short MINS_IN_HOUR = 60;

   private long  currentTime;
   private int currentMillis;
   private int currentSecs;
   private int currentMins;
   private int currentHours;
   private int previousHours;
   private int currentDays;

   {
      currentTime = 0;
   }

   /////////////////////Constructors//////////////////////////////////
   /**
 * Constructor of no arguments
 * */
   public TimeFormater(){
      this.initialize();
   }

   /**
 * Constructor taking the currentTime
 * */
   public TimeFormater(long time){
      this.initialize(time);
   }

   /////////////////////Public Methods////////////////////////////////
   //
   //
   //
   public String getDays(){
      String days = new String("" + this.currentDays);
      return days;
   }

   //
   //
   //
   public String getHours(){
      String hours = String.format("%02d", this.currentHours);
      return hours;
   }

   //
   //
   //
   public String getMilliSeconds(){
      String millis = String.format("%03d", this.currentMillis);
      return millis;
   }

   //
   //
   //
   public String getMinutes(){
      String minutes = String.format("%02d", this.currentMins);
      return minutes;
   }

   //
   //
   //
   public String getSeconds(){
      String seconds = String.format("%02d", this.currentSecs);
      return seconds;
   }

   //
   //
   //
   public void setTime(long millis){
      this.currentTime = millis;
      this.calculateTime();
   }

   //
   //
   //
   public String toString(){
      String returnString = new String("" + this.currentDays + ":");
      returnString += String.format("%02d:" , this.currentHours);
      returnString += String.format("%02d:" , this.currentMins);
      returnString += String.format("%02d." , this.currentSecs);
      returnString += String.format("%03d"  , this.currentMillis);
      return returnString;
   }

   //////////////////////////Private Methods//////////////////////////

   //
   //
   //
   //
   private void calculateTime(){
      Calendar cal = Calendar.getInstance();
      cal.setTimeInMillis(this.currentTime);
      this.currentMillis = cal.get(Calendar.MILLISECOND);
      this.currentSecs   = cal.get(Calendar.SECOND);
      this.currentMins   = cal.get(Calendar.MINUTE);
      int hours          = cal.get(Calendar.HOUR_OF_DAY);
      if(hours != this.previousHours){
         ++this.currentHours;
         this.previousHours = hours;
      }
      if(this.currentHours >= HOURS_IN_DAY){
         ++this.currentDays;    //A Day = 24 hours
         this.currentHours = 0; //Reset the hours
      }
   }

   //
   //
   //
   //
   private void initialize(){
      this.initialize(this.currentTime);
   }

   //
   //
   //
   //
   private void initialize(long time){
      Calendar cal = Calendar.getInstance();
      this.currentTime = time;
      cal.setTimeInMillis(time);
      this.currentMillis = cal.get(Calendar.MILLISECOND);
      this.currentSecs   = cal.get(Calendar.SECOND);
      this.currentMins   = cal.get(Calendar.MINUTE);
      this.previousHours = cal.get(Calendar.HOUR_OF_DAY);
      this.currentDays   = 0;
   }
}
