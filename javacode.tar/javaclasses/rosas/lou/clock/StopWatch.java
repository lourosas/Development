/**
*/
package rosas.lou.clock;

import java.lang.*;
import java.util.*;
import java.text.DateFormat;
import rosas.lou.clock.WatchMechanism;
import rosas.lou.clock.TimeFormater;
import rosas.lou.clock.ClockState;

public class StopWatch implements Runnable{
   private short querryTime;
   private long  startTime;
   private long  stopTime;
   private long  elapsedTime;
   private LinkedList<Long> lapTimes;
   private List<TimeListener> tl_List;
   private Date startDate;
   private Date currentDate;
   private WatchMechanism watchMechanism;
   private State state;
   //Set this here, but not prepared to set up a Singleton, just yet
   private static StopWatch singleton;
   private RunState runState;
   private TimeFormater timeFormater;
   
   {
      querryTime     = 1000;  //Initialize to 1 second of querry
      startTime      = 0;
      stopTime       = 0;
      elapsedTime    = 0;
      startDate      = null;
      currentDate    = null;
      lapTimes       = null;
      tl_List        = null;
      watchMechanism = null;
      timeFormater   = null;
      state          = State.STOP;
      runState       = RunState.RUN;
   }

   //////////////////////Constructor//////////////////////////////////
   /**
   */
   public StopWatch(){
      this.watchMechanism = WatchMechanism.getInstance();
      this.watchMechanism.setRunState(RunState.RUN);
      //Start the Watch Mechanism
      Thread t = new Thread(this.watchMechanism);
      t.start();
   }

   /**
   Constructor setting the Querry Time in Milliseconds
   */
   public StopWatch(short time){
      this.watchMechanism = WatchMechanism.getInstance();
      this.setQuerryTime(time);
      //Start the Watch Mechanism
      Thread t = new Thread(this.watchMechanism);
      t.start();
   }

   ///////////////////Public Methods//////////////////////////////////
   /**
 * */
   public void addTimeListener(TimeListener tl){
      try{
         this.tl_List.add(tl);
      }
      catch(NullPointerException npe){
         this.tl_List = new LinkedList<TimeListener>();
         this.tl_List.add(tl);
      }
      finally{
         this.publishCurrentState();
         this.publishElapsedTime();
      }
   }
   /**
 * */
   public void kill(){
      this.setRunState(RunState.STOP);
      this.watchMechanism.setRunState(RunState.STOP);
   }

   /**
   */
   public void lap(){}

   /**
   */
   public void reset(){}

   /**
   Implementing the run() method as part of the Runnable Interface
   */
   public void run(){
      //How do I want to proceed with this???  Good Question
      while(this.getRunState() == RunState.RUN){
         try{
            if(this.getState() == State.RUN){
               this.stopTime = this.watchMechanism.getCurrentTime();
               this.calculateElapsedTime();
               this.publishElapsedTime();
            }
            else if(this.getState() == State.STOP){
               this.calculateElapsedTime();
               this.publishElapsedTime();
            }
            Thread.sleep(querryTime);
         }
         catch(InterruptedException ie){}
      }
   }

   /**
   */
   public void setQuerryTime(short time){
      this.querryTime = time;
   }

   /**
   */
   public void start(){
      this.setState(State.START);
      this.publishCurrentState();
      this.startTime = this.watchMechanism.getCurrentTime();
      this.startDate = this.watchMechanism.getCurrentDate();
      this.setState(State.RUN);
   }

   /**
   */
   public void stop(){
      this.stopTime = this.watchMechanism.getCurrentTime();
      this.setState(State.STOP);
   }

   ////////////////////////////Private Methods////////////////////////
   /**
   */
   private void calculateElapsedTime(){
      //This may have to change:  based on the different states
      this.elapsedTime += this.stopTime - this.startTime;
      //this.elapsedTime = this.stopTime - this.startTime;
      this.startTime   = this.stopTime;
   }

   /**
 * */
   private RunState getRunState(){
      return this.runState;
   }

   /**
   */
   private State getState(){
      return this.state;
   }

   /**
   */
   private void publishCurrentState(){
      ClockState clockState = new ClockState(this.getState());
      try{
         //Send it to the TimeListeners
         Iterator<TimeListener> it = this.tl_List.iterator();
         while(it.hasNext()){
            TimeListener tl = it.next();
            tl.update(clockState);
         }
      }
      catch(NullPointerException npe){}
   }

   /**
   */
   private void publishElapsedTime(){
      try{
         this.timeFormater.setTime(this.elapsedTime);
      }
      catch(NullPointerException npe){
         this.timeFormater = new TimeFormater(this.elapsedTime);
      }
      try{
         //Send to the TimeListeners
         Iterator<TimeListener> it = this.tl_List.iterator();
         ClockState clockState = new ClockState(this.getState());
         while(it.hasNext()){
            TimeListener tl = it.next();
            tl.update(this.timeFormater);
            tl.update(this.timeFormater, clockState);
            tl.update(this);
            
         }
      }
      catch(NullPointerException npe){}
   }

   /**
 * */
   private void setRunState(RunState state){
      this.runState = state;
   }

   /**
   */
   private void setState(State state){
      this.state = state;
   }
}
