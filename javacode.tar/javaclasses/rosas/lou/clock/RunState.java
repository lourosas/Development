/***/
package rosas.lou.clock;

import java.util.*;
import java.lang.*;
import rosas.lou.clock.*;

public enum RunState{STOP, RUN}
