/**
*/

package rosas.lou.clock;

import java.util.*;
import java.lang.*;
import java.text.DateFormat;
import rosas.lou.clock.*;

public class Clock{
   private long time;
   private Date date;

   {
      time = 0;
      date = null;
   }

   //*********************Constructor********************************
   /*
   Constructor of no arguments
   */
   public Clock(){}

   //*********************Public Methods*****************************
   /*
   */
   public long getTime(){
      this.time = Calendar.getInstance().getTimeInMillis();
      this.date = Calendar.getInstance().getTime();
      return this.time;
   }

   /*
   */
   public Date getDate(){
      this.date = Calendar.getInstance().getTime();
      return this.date;
   }
}
