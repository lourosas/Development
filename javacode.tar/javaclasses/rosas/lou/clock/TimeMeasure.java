/*
*/
package rosas.lou.clock;

public enum TimeMeasure{ MILLISECS, SECS, DATE, DATEFORMAT}