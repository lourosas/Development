/********************************************************************
The RPN Fraction Calculator Application.
Copyright (C) 2007 Lou Rosas

This file is part of RPNFractionCalculator
RPNFractionCalculator is free software; you can redistribute it
and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

RPNFractionCalculator is distributed in the hope that it will be
useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
package rosas.lou;

import java.lang.*;
import java.util.*;
/********************************************************************
An Exception class by Lou Rosas.  This Exception is thrown by any
set of classes wishing to interface with the Fraction Object
********************************************************************/
public class FractionException extends RuntimeException{
   
   //Public static Final Attributes
   public static final short NO_FRACTION           = 0x0;
   public static final short ZERO_DENOMINATOR      = 0x1;
   public static final short NO_DENOMINATOR        = 0x2;
   public static final short NO_NUMERATOR          = 0x4;
   public static final short ZERO_NUMERATOR        = 0x8;
   public static final short ONE_DENOMINATOR       = 0x10;
   public static final short BAD_PROPER_VALUE      = 0x20;
   public static final short ZERO_PROPER_VALUE     = 0x40;
   
   //Private attributes
   private short reason;
   
   /***********************Public Methods***************************/
   /*****************************************************************
   Constructor of no arguments
   *****************************************************************/
   public FractionException(){
      this(NO_FRACTION);
   }
   
   /*****************************************************************
   Constructor setting the reason for the exception
   *****************************************************************/
   public FractionException(short reason){
      //Call the super class
      super("Fraction Exception");
      //Set the reason
      this.setReason(reason);
   }
   
   /*****************************************************************
   Get the reason for the exception
   *****************************************************************/
   public short getReason(){
      return this.reason;
   }
   
   /***********************Private Methods**************************/
   /*****************************************************************
   Set the reason for the exception as related to the Fraction
   *****************************************************************/
   private void setReason(short currentReason){
      this.reason = currentReason;
   }
}
