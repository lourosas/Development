/********************************************************************
The RPN Fraction Calculator Application.
Copyright (C) 2007 Lou Rosas

This file is part of RPNFractionCalculator
RPNFractionCalculator is free software; you can redistribute it
and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

RPNFractionCalculator is distributed in the hope that it will be
useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
package rosas.lou;

import java.lang.*;
import java.util.*;
import rosas.lou.FractionException;

/*******************************************************************
The Fraction class by Lou Rosas.  This class contains all the
attributes and methods related to Fration objects, as well as
the appropriate arithmetic operation methods needed by each
Fraction object.
*******************************************************************/
public class Fraction{
   //Private Attributes
   private int     numerator;
   private int     denominator;
   private boolean isProper;  //True--> display as proper
                              //False-->display as improper
                              
   /************************Public Methods*************************/
   /****************************************************************
   Constructor of no arguments
   Throws:  FractionException
   ****************************************************************/
   public Fraction() throws FractionException{
      //Set the Fraction to numerically 0
      this(0,0,1);
   }
   
   /****************************************************************
   Constructor accepting a numerator value only
   Sets the denominator to 1.
   Throws:  FractionException
   ****************************************************************/
   public Fraction(int numerator) throws FractionException{
      this(0, numerator, 1);
   }
   
   /****************************************************************
   Constructor accepting a numerator and denominator value.  The
   proper value is set to zero.
   Throws:  FractionException
   ****************************************************************/
   public Fraction(int num, int den) throws FractionException{
      //Set the fraction with the proper value set to 0
      this(0,num,den);
   }
   
   /****************************************************************
   Constructor accepting the proper value, numerator and denominator
   Throws:  FractionException.
   ****************************************************************/
   public Fraction(int properValue, int numerator, int denominator)
   throws FractionException{
      try{
         this.setFraction(properValue, numerator, denominator);
         //By Default, set the display state to true
         this.setDisplayState(true);
      }
      catch(FractionException fe){
         throw fe;
      }
   }

   /****************************************************************
   Constructor accepting the a String.  This string contians the
   information related to a Fraction-->Proper Value (if there is
   one), numerator and denominator.  This constructor will
   take the String and parse it into the appropriate fractional
   parts-->particularly the Numerator and Denominator.
   Throws:  FractionException
   ****************************************************************/
   public Fraction(String fractionString) throws FractionException{
      int pv, num, den;
      try{
         pv  = this.grabProperValue(fractionString);
      }
      catch(FractionException fe){
         short reason = fe.getReason();
         //If the FractionException is to set the Proper Value to 0,
         //do just that, otherwise, throw the Exception
         if(reason == FractionException.ZERO_PROPER_VALUE)
            pv = 0;
         else
            throw(fe);
      }
      try{
         num = this.grabNumerator(fractionString);
      }
      catch(FractionException fe){
         short reason = fe.getReason();
         //If the FractionException is set the Numerator to 0,
         //do just that, otherwise, throw the exception
         if(reason == FractionException.ZERO_NUMERATOR)
            num = 0;
         else
            throw(fe);
      }
      try{
         den = this.grabDenominator(fractionString);
      }
      catch(FractionException fe){
         short reason = fe.getReason();
         //If the FractionException is set the Denominator to 1,
         //do just that, otherwise, throw the exception
         if(reason == FractionException.ONE_DENOMINATOR)
            den = 1;
         else
            throw(fe);
      }
      this.setFraction(pv, num, den);
      //By Default, set the display state to display proper value,
      //numerator, denominator
      this.setDisplayState(true);
   }
   
   /****************************************************************
   Copy constructor
   Throws:  FractionException
   ****************************************************************/
   public Fraction(Fraction copyFraction) throws FractionException{
      int num = copyFraction.getNumerator();
      int den = copyFraction.getDenominator();
      this.setFraction(num, den);
      this.setDisplayState(copyFraction.getDisplayState());
   }
   
   
   /****************************************************************
   Add this fraction with another input fraction, returning the
   result in a THIRD Fraction.  Niether this fraction NOR the
   input fraction is modified.
   Throws: FractionException
   ****************************************************************/
   public Fraction add(Fraction otherFraction)
   throws FractionException{
      int addNum  = otherFraction.getNumerator();
      int addDen  = otherFraction.getDenominator();
      int thisNum = this.getNumerator();
      int thisDen = this.getDenominator();
      
      int returnNum = (thisNum*addDen) + (thisDen*addNum);
      int returnDen = thisDen * addDen;
      
      return (new Fraction(returnNum, returnDen));
   }
   
   /****************************************************************
   Subtract this fraction with another input fraction, returning
   the result in a THIRD Fraction.  Niether this fraction NOR the
   input fraction is modified.
   Throws:  FractionException
   ****************************************************************/
   public Fraction subtract(Fraction otherFraction)
   throws FractionException{
      int subNum   = otherFraction.getNumerator();
      int subDen   = otherFraction.getDenominator();
      //Subtraction is the same as adding a negative, so just do
      //that.
      return(this.add(new Fraction(-subNum, subDen)));
   }
   
   /****************************************************************
   Multiply this fraction with another input fraction, returning
   the result in a THIRD Fraction.  Niether this fraction NOR the
   input fraction is modified.
   Throws:  FractionException
   ****************************************************************/
   public Fraction multiply(Fraction otherFraction)
   throws FractionException{
      int mulNum  = otherFraction.getNumerator();
      int mulDen  = otherFraction.getDenominator();
      int thisNum = this.getNumerator();
      int thisDen = this.getDenominator();
      
      int returnNum = thisNum*mulNum;
      int returnDen = thisDen*mulDen;
      
      return(new Fraction(returnNum, returnDen));
   }
   
   /****************************************************************
   Divide this fraction with another input fraction, returning the
   result in a THIRD Fraction.  Niether this fraction NOR the input
   Fraction is modified.
   Throws:  FractionException
   ****************************************************************/
   public Fraction divide(Fraction otherFraction)
   throws FractionException{
      /*Division is the multiplication of the INVERSE of the
        second Fraction.
        Thus, go ahead and return the product of this Fraction and
        the inverse of the the input Fraction.*/
      return(this.multiply(otherFraction.getInverse()));
   }
   
   /****************************************************************
   Return how the fraction is to be displayed:  true if the
   fraction is to be displayed in proper format, false if the
   fraction is to be displayed in improper format.
   ****************************************************************/
   public boolean getDisplayState(){
      return this.isProper;
   }
   
   /****************************************************************
   Set how the Fraction is to be displayed:  true-->display in
   proper format, false-->display in improper format.
   ****************************************************************/
   public void setDisplayState(boolean displayProper){
      this.isProper = displayProper;
   }
   
   /****************************************************************
   Get the denominator of the Fraction
   ****************************************************************/
   public int getDenominator(){
      return this.denominator;
   }
   
   /****************************************************************
   Get the numerator of the Fraction
   ****************************************************************/
   public int getNumerator(){
      return this.numerator;
   }
   
   /****************************************************************
   Get the inverse of the Fraction and return in a new Fraction
   Throws:  FractionException
   ****************************************************************/
   public Fraction getInverse() throws FractionException{
      int num = this.getNumerator();
      int den = this.getDenominator();
      
      //Set up a new Fraction-->setting the denominator as the
      //numerator and the numerator as the denominator.
      return(new Fraction(den, num));
   }
   
   /****************************************************************
   Print out the Fraction.  If the Fraction is to be displayed
   proper, message the displayProper() method, else, message the
   displayImproper() method.
   This is the overridden method of the toString() method inherited
   from the Object class
   ****************************************************************/
   public String toString(){
      String returnString;
      //Display in proper format? message displayProper()
      //else message displayImproper()
      if(this.getDisplayState()){
         returnString = new String(this.displayProper());
      }
      else{
         returnString = new String(this.displayImproper());
      }
      return returnString;
   }
   
   /*********************Private Methods***************************/
   /****************************************************************
   Check the validity of the fraction.  Essentially, check if the
   Fraction is Undefined (the denominator is 0).  If the Fraction
   is U.D., throw FractionException-->ZERO_DENOMINATOR.
   Throws:  FractionException
   ****************************************************************/
   private void checkValidity() throws FractionException{
      FractionException fe;
      
      if(this.getDenominator() == 0){
         fe = new FractionException(
                                FractionException.ZERO_DENOMINATOR);
         throw fe;
      }
   }
   
   /****************************************************************
   Display the fraction in proper format.
   This is not that hard, if the numerator > denominator,
   set the proper value  as the numerator/denominator and display
   the numerator as numerator%denominator.  Don't change the 
   ACTUAL values in the Fraction, rather, just change the value
   that need to be displayed.  If the numerator or denominator are
   negative, indicate that in a boolean, reverse the sign of the
   negative portion and and the '-' to the front of the string.
   Return this in a String.
   ****************************************************************/
   private String displayProper(){
      int num               = this.getNumerator();
      int den               = this.getDenominator();
      String returnString   = new String();
      boolean isNegative    = false;
      if(num < 0 && den > 0){
         isNegative = true;
         num        = -num;
      }
      else if(num > 0 && den < 0){
         isNegative = true;
         den        = -den;
      }
      //If there is not numerator value, display in whole number
      //format--num/1
      if(num%den == 0){
         if(isNegative){
            returnString += "-";
         }
         returnString += (num/den) +  "/" + den;
      }
      //If there is no proper value, the numerator and denominator
      //should only be displayed-->this can be handled by the
      //displayImproper() method
      else if(num/den == 0)
         returnString = this.displayImproper();
      else{
         //The Fraction has multiple components
         //Grab the proper value, the remainder (numerator)
         //and place over the denominator.
         if(isNegative){
            returnString += "-";
         }
         returnString += num/den + " " + num%den + "/" + den;
      }
      return returnString;
   } 
   
   
   /****************************************************************
   Display the Fraction in the original (raw) format, don't do
   anything to display it differently than how it is stored.
   Essentially, the same thing as the else block in the
   displayProper() method.
   ****************************************************************/
   private String displayImproper(){
      int     num          = this.getNumerator();
      int     den          = this.getDenominator();
      String  returnString = new String();
      boolean isNegative   = false;

      if(num < 0 && den > 0){
         isNegative = true;
         num        = -num;
      }
      else if(num > 0 && den < 0){
         isNegative = true;
         den        = -den;
      }
      if(isNegative){
         returnString += "-";
      }    
      returnString += num + "/" + den; 
      return returnString;
   }

   /****************************************************************
   Find the gap value in the Fraction String.  This aids in
   parsing the fraction into:  the proper value, numerator and
   denominator.  If the gap is non-existent, return a 0
   Throws:  NullPointerException
   ****************************************************************/
   private int findGap(String data) throws NullPointerException{
      int gapValue           = 0;
      boolean characterFound = false;
      boolean gapFound       = false;
      int i                  = 0;
      try{
         int stringLength = data.length();
         while(i < stringLength && !gapFound){
            if(data.charAt(i) != ' '){
               characterFound = true;
               while(i < stringLength && data.charAt(i) != ' ') i++;
            }
            else if(characterFound){
               gapFound = true;
               gapValue = i;
            }
            else i++;
         }
      }
      catch(NullPointerException npe){
         throw(npe);
      }

      return gapValue;
   }

   /****************************************************************
   Find the '/' in the Fraction String.  If the slash does not
   exist, return a 0
   Throws:  NullPointerException
   ****************************************************************/
   private int findSlash(String data) throws NullPointerException{
      int slashValue;
      int i = 0;
      try{
         int stringLength = data.length();
         while(i < stringLength && data.charAt(i) != '/') i++;
      }
      catch(NullPointerException npe){
         throw npe;
      }
      slashValue = i;

      return slashValue;
   }

   /****************************************************************
   Given the input string, find the denominator portion of the
   string.
   Throws:  FractionException
   ****************************************************************/
   private int grabDenominator(String data) throws FractionException{
      int denominator = 0;
      String fractionString = new String();

      try{
         //Find the slash ('/')
         int slash = this.findSlash(data);
         //Get the string starting at the number after the slash (/)
         //to the end.
         fractionString = data.substring(slash + 1);
         //Remove all the whitespace
         fractionString = fractionString.trim();
         //Set the denominator by parsing the remaining string
         denominator = Integer.parseInt(fractionString);
      }
      catch(IndexOutOfBoundsException obe){
         //If there is no slash, set the denominator to 1
         short reason = FractionException.ONE_DENOMINATOR;
         throw(new FractionException(reason));
      }
      catch(NumberFormatException nfe){
         /*If the string in the denominator is not all numerical,
           indicate that by throwing a NO_DENOMINATOR
           FractionException (the method doing the messaging
           SHOULD ignore the value of the denominator returned*/
         short reason = FractionException.NO_DENOMINATOR;
         throw(new FractionException(reason));
      }
      catch(NullPointerException npe){
         /*If no text is entered, go ahead and set the denominator
           to 1*/
         short reason = FractionException.ONE_DENOMINATOR;
         throw(new FractionException(reason));
      }
      return denominator;
   }

   /****************************************************************
   Given the input string, find the numerator portion of the
   string.
   Throws:  FractionException
   ****************************************************************/
   private int grabNumerator(String data) throws FractionException{
      int numerator = 0;
      String fractionString = new String();
      try{
         int gap   = this.findGap(data);
         int slash = this.findSlash(data);
         //Get the substring between the Proper value (if there is
         //one) and the slash ('/')
         fractionString = data.substring(gap, slash);
         //Remove all the white space
         fractionString = fractionString.trim();
         //Set the numerator by parsing the remaining string
         numerator = Integer.parseInt(fractionString);
      }
      catch(IndexOutOfBoundsException obe){
         short reason = FractionException.ZERO_NUMERATOR;
         throw(new FractionException(reason));
      }
      catch(NumberFormatException nfe){
         //If the string in the numerator is not all numerical,
         //indicate that by throwing a NO_NUMERATOR
         //FractionException (the method doing the messaging
         //SHOULD ignore the value of the numerator returned
         short reason = FractionException.NO_NUMERATOR;
         throw(new FractionException(reason));
      }
      //If there is no string at all, set the Numerator to 0
      catch(NullPointerException npe){
         short reason = FractionException.ZERO_NUMERATOR;
         throw(new FractionException(reason));
      }
      return numerator;
   }

   /****************************************************************
   Given an input string, find the proper value portion of the
   string.
   Throws:  FractionException
   ****************************************************************/
   private int grabProperValue(String data) throws FractionException{
      int properValue = 0;
 
      try{
         int gap = this.findGap(data);
         if(gap != 0){
            String properValueString = data.substring(0, gap);
            //Remove the white space in the Proper Value String
            properValueString = properValueString.trim();
            properValue       = Integer.parseInt(properValueString);
         }
      }
      //If there is nothing in the string, just return the
      //Proper Value as is (which is 0)
      catch(NullPointerException npe){
         short reason = FractionException.ZERO_PROPER_VALUE;
         throw(new FractionException(reason));
      }
      //If there is an exception in the number format, reset the
      //proper value to 0 and throw the FractionException
      catch(NumberFormatException nfe){
         short reason = FractionException.BAD_PROPER_VALUE;
         throw(new FractionException(reason));
      }
      return properValue;
   }

   /****************************************************************
   Reduce the Fraction to the lowest form (if reducible)-->
   This means reducing the numerator and denominator by their
   greatest common divisor (GCD)
   ****************************************************************/
   private void reduce(){
      //Set the greatest common Divisor to the denominator
      int gcd         = this.getDenominator();
      boolean isFound = false;
      
      //Try to find the greatest common divisor
      while(!isFound && (gcd > 1)){
         int testNum = this.getNumerator()%gcd;
         int testDen = this.getDenominator()%gcd;
         if(testNum == 0 && testDen == 0){
            isFound = true;
         }
         else{
            --gcd;
         }
      }
      //If the Greatest Common Divisor is found, reduce both
      //The numerator and denominator by that value
      if(isFound){
         this.setNumerator(this.getNumerator()/gcd);
         this.setDenominator(this.getDenominator()/gcd);
      }
   }
   
   /****************************************************************
   Given the numerator and denominator, set the fields accordingly
   and check the validity of the current Fraction, throw a
   FractionException if not valid (den == 0)
   ****************************************************************/
   private void setFraction(int num, int den)
   throws FractionException{
      //If the den < 0, set num < 0 and den > 0
      if(den < 0){
         num = -num;
         den = -den;
      }
      try{
         this.setNumerator(num);
         this.setDenominator(den);
         //Check the validity of the fraction
         this.checkValidity();
         //if the validity check passes, reduce
         this.reduce();
      }
      catch(FractionException fe){
         throw(fe);
      }
   }
   
   /****************************************************************
   Given the Proper value, numerator, denominator, set the fields
   accordingly.  Since there is no proper value field, the proper
   value is rolled into the numerator field by:  num += pv*den.
   From this vantage point, the only time this matters is when the
   Fraction needs to be printed-->which is appropriately handled
   already.
   ****************************************************************/
   private void setFraction(int pv, int num, int den)
   throws FractionException{
      boolean isNegative = false;
      //Need to be able to handle negative numbers!!!
      /*Handle the negative numbers by making everything positive,
        setting a boolean, performing the correct fraction
        arithmetic and then setting the negative based on the
        boolean.*/
      if(pv < 0 || num < 0 || den < 0){
         isNegative = true;
      }
      if(isNegative){
         if(pv < 0){
            pv = -pv;
         }
         else if(num < 0){
            num = - num;
         }
         else if(den < 0){
            den = -den;
         }
      }
      //Set up the numerator to be improper
      int newNum = num + (pv*den);

      if(isNegative){
         newNum = -newNum;
      }
      
      //The call the setFraction(int, int) to set the Numerator
      //and Denominator fields
      this.setFraction(newNum, den);
   }
   
   /****************************************************************
   Set the numerator field of the Fraction
   ****************************************************************/
   private void setNumerator(int num){
      this.numerator = num;
   }
   
   /****************************************************************
   Set the denominator field of the Fraction.
   ****************************************************************/
   private void setDenominator(int den){
      this.denominator = den;
   }
   
}